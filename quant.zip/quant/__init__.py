# -*- coding:utf-8 -*-

"""
Asynchronous driven quantitative trading framework.

Author: HuangTao
Date:   2017/04/26
Email:  huangtao@ifclover.com
"""

__author__ = "HuangTao"
__version__ = (0, 1, 4)
