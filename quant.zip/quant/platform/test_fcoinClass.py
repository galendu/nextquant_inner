# encoding: utf-8
import asyncio
from quant.platform.fcoin_margin import FCoinMarginRestAPI
from quant.order import ORDER_ACTION_BUY, ORDER_TYPE_MARKET, ORDER_TYPE_LIMIT
from quant.tasks import SingleTask

fcoin = FCoinMarginRestAPI('https://api.fcoin.com/v2/', 'bb2b72a5d8fc4bd6833c0a38ac636880','4f2ffb9bb3474d9f98dd61174796532d')
task = asyncio.ensure_future(fcoin.create_order(ORDER_ACTION_BUY,'btcusdt', None, 1, ORDER_TYPE_MARKET))
loop = asyncio.get_event_loop()
loop.run_until_complete(task)
# print('Task:', task)
print('Task Result:', task.result())