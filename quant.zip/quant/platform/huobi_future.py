import json
import hmac
import copy
import gzip
import base64
import urllib
import hashlib
import datetime
import asyncio
import time
from urllib import parse
from urllib.parse import urljoin

from quant.error import Error
from quant.order import Order
from quant.utils import tools
from quant.utils import logger
from quant.tasks import SingleTask
from quant.position import Position
from quant.const import HUOBI_FUTURE
from quant.utils.websocket import Websocket
from quant.asset import Asset, AssetSubscribe
from quant.utils.http_client import AsyncHttpRequests
from quant.utils.decorator import async_method_locker
from quant.order import ORDER_ACTION_BUY, ORDER_ACTION_SELL
from quant.order import ORDER_TYPE_LIMIT, ORDER_TYPE_MARKET
from quant.order import ORDER_STATUS_SUBMITTED, ORDER_STATUS_PARTIAL_FILLED, ORDER_STATUS_FILLED, \
    ORDER_STATUS_CANCELED, ORDER_STATUS_FAILED

from quant.const import (
    MARKET_TYPE_KLINE,
    MARKET_TYPE_KLINE_5M,
    MARKET_TYPE_KLINE_15M
)

CONTRACT_TYPE_DIC = {
    'CW': 'this_week',
    'NW': 'next_week',
    'CQ': 'quarter'
}


KLINE_TYPE_DIC = {
    MARKET_TYPE_KLINE: '1min',
    MARKET_TYPE_KLINE_5M: '5min',
    MARKET_TYPE_KLINE_15M: '15min'
}



class HuobiFutureRestAPI:
    """ Huobi期货交易 交割合约 REST API 封装
    """

    def __init__(self, host, access_key, secret_key):
        """ 初始化
        @param host 请求的host
        @param access_key 请求的access_key
        @param secret_key 请求的secret_key
        @param passphrase API KEY的密码
        """
        self._host = host
        self._access_key = access_key
        self._secret_key = secret_key


    def get_symbol(self, instrument_id):
        buf = [i for i in instrument_id if i.isalpha()]
        symbol = ''.join(buf)
        symbol = symbol.replace('USD', '')
        return symbol



    async def get_position(self):
        """ 获取单个合约持仓信息
        @param instrument_id 合约ID，如BTC-USD-180213
        """
        uri = "/api/v1/contract_position_info"
        success, error = await self.request("POST", uri, auth=True)
        return success, error

    async def create_order(self, instrument_id, trade_type, price, size, match_price=0, leverage=10):
        """ 下单
        @param instrument_id 合约ID，如BTC-USD-180213
        @param trade_type 交易类型，1 开多 / 2 开空 / 3 平多 / 4 平空
        @param price 每张合约的价格
        @param size 买入或卖出合约的数量（以张计数）
        @param match_price 是否以对手价下单（0 不是 / 1 是），默认为0，当取值为1时。price字段无效
        @param leverage 要设定的杠杆倍数，10或20
        """
        trade_type_dict = {
            '1': ('buy', 'open'),
            '2': ('sell', 'open'),
            '3': ('sell', 'close'),
            '4': ('buy', 'close')
        }
        direction, offset = trade_type_dict.get(str(trade_type), (None, None))



        order_price_type = ''
        if int(match_price) == 0:
            order_price_type = 'limit'
        else:
            order_price_type = 'post_only'


        body = {
            "contract_code": instrument_id,
            "price": price,
            "volume": size,
            "direction": direction,
            "offset": offset,
            "order_price_type": order_price_type,
            "lever_rate": leverage
        }
        # logger.info('huobi创建订单 ', body, 'trade_type ', trade_type)
        success, error = await self.request("POST", "/api/v1/contract_order", body=body, auth=True)
        return success, error

    async def revoke_order(self, instrument_id, order_no):
        """ 撤单
        @param instrument_id 合约ID，如BTC-USD-180213
        @param order_id 订单ID
        """
        if order_no == None:
            return None, Error('订单号不能为None')
        uri = "/api/v1/contract_cancel"

        body = {
            'symbol': self.get_symbol(instrument_id),
            'order_id': order_no
        }
        success, error = await self.request("POST", uri, body=body, auth=True)
        if success:
            errors = success.get('errors', list())
            for item in errors:
                return None, item

        return success, error

    async def revoke_all_orders(self, instrument_id):
        """ 撤销全部挂单
        @param instrument_id 合约ID，如BTC-USD-180213
        """
        uri = "/api/v1/contract_cancelall"

        body = {
            "symbol": self.get_symbol(instrument_id),
            "contract_code": instrument_id
        }
        success, error = await self.request("POST", uri, body=body, auth=True)
        if error and error.get('err_code') == 1051:
            return True, None
        return success, error

    async def revoke_orders(self, instrument_id, order_ids):
        """ 批量撤单
        @param instrument_id 合约ID，如BTC-USD-180213
        @param order_ids 订单id列表
        """
        assert isinstance(order_ids, list)

        uri = "/api/v1/contract_cancel"

        body = {
            'symbol': self.get_symbol(instrument_id),
            'order_id': ','.join(order_ids)
        }
        success, error = await self.request("POST", uri, body=body, auth=True)
        return success, error

    async def get_order_info(self, instrument_id, order_id):
        """ 获取订单信息
        @param instrument_id 合约ID，如BTC-USD-180213
        @param order_id 订单ID
        """
        symbol = self.get_symbol(instrument_id)
        uri = "/api/v1/contract_order_info"
        body = {
            'symbol': symbol,
            'order_id': order_id
        }
        success, error = await self.request("POST", uri, body=body, auth=True)
        return success, error

    async def get_order_list(self, instrument_id, state):
        """ 获取订单列表
        @param instrument_id 合约ID，如BTC-USD-180213
        @param state 订单状态("-2":失败,"-1":撤单成功,"0":等待成交 ,"1":部分成交, "2":完全成交,"3":下单中,"4":撤单中,"6": 未完成（等待成交+部分成交），"7":已完成（撤单成功+完全成交））
        @param _from Request paging content for this page number.（Example: 1,2,3,4,5. From 4 we only have 4, to 4 we only have 3）
        @param to Request page after (older) this pagination id. （Example: 1,2,3,4,5. From 4 we only have 4, to 4 we only have 3）
        @param limit Number of results per request. Maximum 100. (default 100)
        """
        state_dic = {
            '-2': 7,
            '-1': 7,
            '0': 3,
            '1': 4,
            '2': 6,
            '3': 2,
            '4': 7,
            '6': 3,
            '7': 5
        }
        symbol = self.get_symbol(instrument_id)
        uri = "/api/v1/contract_hisorders"
        body = {
            "status": state_dic.get(state),
            "type": 1,
            "symbol": symbol,
            "trade_type": 0,
            "create_date": 90
        }
        success, error = await self.request("POST", uri, body=body, auth=True)
        return success, error

    async def get_user_account(self):
        """ 获取账户信息
        """
        success, error = await self.request("POST", "/api/v1/contract_account_info", auth=True)
        return success, error

    async def get_contract(self):
        success, error = await self.request("GET", '/api/v1/contract_contract_info', auth=False)
        return success, error
    
    async def get_history_kline(self, symbol, period, size):

        period = KLINE_TYPE_DIC.get(period)
        e = Error("没有该时间周期")
        if not period:
            return None, e

        params = {
            'symbol': symbol,
            'period': period,
            'size': int(size)
        }
        success, error = await self.request("GET", '/market/history/kline', params=params)
        return success, error

    async def request(self, method, uri, params=None, body=None, headers=None, auth=False):
        """ 发起请求
        @param method 请求方法 GET / POST / DELETE / PUT
        @param uri 请求uri
        @param params dict 请求query参数
        @param body dict 请求body数据
        @param headers 请求http头
        @param auth boolean 是否需要加入权限校验
        """
        url = urljoin(self._host, uri)


        if auth:
            timestamp = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")
            params = params if params else {}
            params.update({"AccessKeyId": self._access_key,
                           "SignatureMethod": "HmacSHA256",
                           "SignatureVersion": "2",
                           "Timestamp": timestamp})

            host_name = urllib.parse.urlparse(self._host).hostname.lower()
            params["Signature"] = self.generate_signature(method, params, host_name, uri)



        if method == "GET":
            headers = {
                "Content-type": "application/x-www-form-urlencoded",
                "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) "
                              "Chrome/39.0.2171.71 Safari/537.36"
            }
        else:
            headers = {
                "Accept": "application/json",
                "Content-type": "application/json"
            }



        _, success, error = await AsyncHttpRequests.fetch(method, url, params=params, data=body, headers=headers,
                                                          timeout=60)
        if error:
            return success, error

        # logger.info('huobi ', success)
        
        if isinstance(success, str):
            success = json.loads(success)

        if success.get("status") != "ok":
            return None, success
        return success.get("data"), None




    def generate_signature(self, method, params, host_url, request_path):
        """ 创建签名
        """
        query = "&".join(["{}={}".format(k, parse.quote(str(params[k]))) for k in sorted(params.keys())])
        payload = [method, host_url, request_path, query]
        payload = "\n".join(payload)
        payload = payload.encode(encoding="utf8")
        secret_key = self._secret_key.encode(encoding="utf8")
        digest = hmac.new(secret_key, payload, digestmod=hashlib.sha256).digest()
        signature = base64.b64encode(digest)
        signature = signature.decode()
        return signature

class HuobiFutureTrade(Websocket):
    """ Huobi Future Trade module
    """

    def __init__(self, **kwargs):
        """ 初始化
        """
        e = None
        if not kwargs.get("account"):
            e = Error("param account miss")
        if not kwargs.get("strategy"):
            e = Error("param strategy miss")
        if not kwargs.get("symbol"):
            e = Error("param symbol miss")
        if not kwargs.get("host"):
            kwargs["host"] = "https://api.hbdm.com"
        if not kwargs.get("wss"):
            kwargs["wss"] = "wss://api.hbdm.com/notification"
        if not kwargs.get("access_key"):
            e = Error("param access_key miss")
        if not kwargs.get("secret_key"):
            e = Error("param secret_key miss")
        if e:
            logger.error(e, caller=self)
            if kwargs.get("init_success_callback"):
                SingleTask.run(kwargs["init_success_callback"], False, e)
            return

        self._account = kwargs["account"]
        self._strategy = kwargs["strategy"]
        self._platform = HUOBI_FUTURE
        self._symbol = kwargs["symbol"]
        self._host = kwargs["host"]
        self._wss = kwargs["wss"]
        self._access_key = kwargs["access_key"]
        self._secret_key = kwargs["secret_key"]
        self._passphrase = kwargs["passphrase"]
        self._asset_update_callback = kwargs.get("asset_update_callback")
        self._order_update_callback = kwargs.get("order_update_callback")
        self._position_update_callback = kwargs.get("position_update_callback")
        self._init_success_callback = kwargs.get("init_success_callback")
        self._contract_update_callback = kwargs.get('contract_update_callback')

        url = self._wss
        super(HuobiFutureTrade, self).__init__(url, send_hb_interval=0)

        self._assets = {}  # 资产 {"BTC": {"free": "1.1", "locked": "2.2", "total": "3.3"}, ... }
        self._orders = {}  # 订单
        self._position = Position(self._platform, self._account, self._strategy, self._symbol)  # 仓位
        self._contract = {}

        self._trade_coin = self._symbol.split('_')[0].lower()
        # 订阅频道
        self._order_channel = "orders.{symbol}".format(symbol=self._trade_coin)
        self._position_channel = "positions.{symbol}".format(symbol=self._trade_coin)

        # 标记订阅订单、持仓是否成功
        self._subscribe_order_ok = False
        self._subscribe_position_ok = False

        # 初始化 REST API 对象
        self._rest_api = HuobiFutureRestAPI(self._host, self._access_key, self._secret_key)

        # 初始化资产订阅
        if self._asset_update_callback:
            AssetSubscribe(self._platform, self._account, self.on_event_asset_update)
            logger.info("platform:", self._platform, "account:", self._account, caller=self)


        # 获取合约信息
        asyncio.get_event_loop().create_task(self.load_contract())

        # 延时连接
        SingleTask.call_later(self.initialize, 1)

        

    @property
    def assets(self):
        return copy.copy(self._assets)

    @property
    def orders(self):
        return copy.copy(self._orders)

    @property
    def position(self):
        return copy.copy(self._position)

    @property
    def contract(self):
        return copy.copy(self._contract)
    

    async def connected_callback(self):
        """ 建立连接之后，授权登陆，然后订阅order和position
        """
        # 身份验证
        # timestamp = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")
        # params = {
        #     "AccessKeyId": self._access_key,
        #     "SignatureMethod": "HmacSHA256",
        #     "SignatureVersion": "2",
        #     "Timestamp": timestamp,
        #     "type": "api"
        # }
        # signature = self._rest_api.generate_signature("GET", params, "api.hbdm.com", "/notification")
        # params["op"] = "auth"
        # params["Signature"] = signature


        timestamp = datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")
        params = {}
        params.update({"AccessKeyId": self._access_key,
                       "SignatureMethod": "HmacSHA256",
                       "SignatureVersion": "2",
                       "Timestamp": timestamp})

        host_name = urllib.parse.urlparse(self._host).hostname.lower()
        params["Signature"] = self._rest_api.generate_signature("GET", params, host_name, "/notification")
        params["op"] = "auth"
        params["type"] = "api"
# "op": "auth",
# "type": "api",
# "AccessKeyId": "e2xxxxxx-99xxxxxx-84xxxxxx-7xxxx",
# "SignatureMethod": "HmacSHA256",
# "SignatureVersion": "2",
# "Timestamp": "2017-05-11T15:19:30",
# "Signature": "4F65x5A2bLyMWVQj3Aqp+B4w+ivaA7n5Oi2SuYtCJ9o=",
        await self.ws.send_json(params)

        # 订阅频道
        params = {
            "op": "sub",
            "topic": self._order_channel
        }
        await self.ws.send_json(params)

        params = {
            "op": "sub",
            "topic": self._position_channel
        }
        await self.ws.send_json(params)

    @async_method_locker("process_binary.locker")
    async def process_binary(self, raw):
        """ 处理websocket上接收到的消息
        @param raw 原始的压缩数据
        """
        msg = json.loads(gzip.decompress(raw).decode())
        logger.debug("msg:", msg, caller=self)

        op = msg.get("op")

        # logger.info('')

        if op == "auth":  # 授权
            if msg["err-code"] != 0:
                e = Error("Websocket connection authorized failed: {}".format(msg))
                logger.error(e, caller=self)
                if self._init_success_callback:
                    SingleTask.run(self._init_success_callback, False, e)
                return
            logger.info("Websocket connection authorized successfully.", caller=self)
        elif op == "ping":  # ping
            params = {
                "op": "pong",
                "ts": msg["ts"]
            }
            await self.ws.send_json(params)
        elif op == "sub":   # 订阅频道返回消息
            # if msg["topic"] != self._order_channel:
            #     return
            if msg["err-code"] != 0:
                if self._init_success_callback:
                    e = Error("subscribe order event error: {}".format(msg))
                    SingleTask.run(self._init_success_callback, False, e)
            else:


                # 获取当前等待成交和部分成交的订单信息
                result, error = await self._rest_api.get_order_list(self._contract['instrument_id'], 6)
                if error:
                    e = Error("get open orders error: {}".format(error))
                    if self._init_success_callback:
                        SingleTask.run(self._init_success_callback, False, e)
                    return
                for order_info in result["orders"]:
                    order = self._update_order(order_info)
 
                # 第一页撤单成功的订单数据，默认20条
                result, error = await self._rest_api.get_order_list(self._contract['instrument_id'], -1)
                if error:
                    e = Error("get open orders error: {}".format(error))
                    if self._init_success_callback:
                        SingleTask.run(self._init_success_callback, False, e)
                    return
                for order_info in result["orders"]:
                    order = self._update_order(order_info)

                # 获取当前持仓
                position, error = await self._rest_api.get_position(self._contract['instrument_id'])
                if error:
                    e = Error("get position error: {}".format(error))
                    if self._init_success_callback:
                        SingleTask.run(self._init_success_callback, False, e)
                    return
                if len(position) > 0:
                    self._update_position(position)
                if self._position_update_callback:
                    SingleTask.run(self._position_update_callback, copy.copy(self._position))


                # 初始化成功
                if self._init_success_callback:
                    SingleTask.run(self._init_success_callback, True, None)

                    
        elif op == "notify":  # 订单更新通知
            if msg["topic"] == self._order_channel:
                msg["utime"] = msg["ts"]
                self._update_order(msg)
            elif msg['topic'] == self._position_channel:
                data = msg['data']
                self._update_position(data)

    def _update_contract(self, contract_list):

        info = None
        for contract in contract_list:
            type_dict = {item:key for key, item in CONTRACT_TYPE_DIC.items()}
            symbol = '{}_{}'.format(contract['symbol'], type_dict.get(contract['contract_type'], ''))
            if symbol == self._symbol:
                info = {
                    'instrument_id': contract['contract_code'],
                    'coin': contract['symbol'],
                    'contract_type': contract['contract_type'],
                    'delivery_date': contract['delivery_date'],
                    'contract_size': float(contract['contract_size']),
                    'tick_size': float(contract['price_tick'])
                }

        if info:
            self._contract = info
            if self._contract_update_callback:
                SingleTask.run(self._contract_update_callback, self._contract)
        else:
            logger.error('未找到合约', caller=self)



    async def load_contract(self):
        contract, error = await self._rest_api.get_contract()
        if error:
            e = Error('get contract error: {}'.format(error))
            if self._init_success_callback:
                SingleTask.run(self._init_success_callback, False, e)

        if contract:
            self._update_contract(contract)
            delivery_date = self._contract['delivery_date'] + '170100'
            update_t = int(time.mktime(time.strptime(delivery_date,'%Y%m%d%H%M%S')))
            delay = update_t - time.time()
            SingleTask.call_later(self.load_contract, delay)


    async def create_order(self, action, price, quantity, order_type=ORDER_TYPE_LIMIT):
        """ 创建订单
        @param action 交易方向 BUY/SELL
        @param price 委托价格
        @param quantity 委托数量(可以是正数，也可以是复数)
        @param order_type 委托类型 limit/market
        """
        if int(quantity) > 0:
            if action == ORDER_ACTION_BUY:
                trade_type = "1"
            else:
                trade_type = "3"
        else:
            if action == ORDER_ACTION_BUY:
                trade_type = "4"
            else:
                trade_type = "2"
        quantity = abs(int(quantity))
        result, error = await self._rest_api.create_order(self._contract['instrument_id'], trade_type, price, quantity)
        if error:
            return None, error
        return str(result["order_id"]), None

    async def revoke_order(self, *order_nos):
        """ 撤销订单
        @param order_nos 订单号，可传入任意多个，如果不传入，那么就撤销所有订单
        * NOTE: 单次调用最多只能撤销100个订单，如果订单超过100个，请多次调用
        """
        # 如果传入order_nos为空，即撤销全部委托单
        if len(order_nos) == 0:
            result, error = await self._rest_api.revoke_all_orders(self._contract['instrument_id'])
            if error:
                return False, error
            else:
                return True, None

        # 如果传入order_nos为一个委托单号，那么只撤销一个委托单
        if len(order_nos) == 1:
            success, error = await self._rest_api.revoke_order(self._contract['instrument_id'], order_nos[0])
            if error:
                if error.get('err_code') == 1071:
                    await self.get_order_info(order_nos[0])
                return order_nos[0], error
            else:
                return order_nos[0], None

        # 如果传入order_nos数量大于1，那么就批量撤销传入的委托单
        if len(order_nos) > 1:
            success, error = [], []
            for order_no in order_nos:
                _, e = await self._rest_api.revoke_order(self._contract['instrument_id'], order_no)
                if e:
                    error.append((order_no, e))
                else:
                    success.append(order_no)
            return success, error

    async def get_open_order_nos(self):
        """ 获取未完全成交订单号列表
        """
        success, error = await self._rest_api.get_order_list(self._contract['instrument_id'], 6)
        if error:
            return None, error
        else:
            order_nos = []
            for order_info in success["orders"]:
                order_nos.append(order_info["order_id"])
            return order_nos, None

    def _update_order(self, order_info):
        """ 更新订单信息
        @param order_info 订单信息
        """

        order_no = str(order_info["order_id"])
        state = str(order_info["status"])
        remain = int(order_info["volume"]) - int(order_info["trade_volume"])
        ctime = order_info["created_at"]

        if state == "5" or state == "7":
            status = ORDER_STATUS_CANCELED
        elif state == "3":
            status = ORDER_STATUS_SUBMITTED
        elif state == "4":
            status = ORDER_STATUS_PARTIAL_FILLED
        elif state == "6":
            status = ORDER_STATUS_FILLED
        else:
            return None

        order = self._orders.get(order_no)
        if not order:
            trade_type = None
            if order_info['direction'] == 'buy' and order_info['offset'] == 'open':
                trade_type = 1
            elif order_info['direction'] == 'sell' and order_info['offset'] == 'open':
                trade_type = 2
            elif order_info['direction'] == 'sell' and order_info['offset'] == 'close':
                trade_type = 3
            elif order_info['direction'] == 'buy' and order_info['offset'] == 'close':
                trade_type = 4

            info = {
                "platform": self._platform,
                "account": self._account,
                "strategy": self._strategy,
                "order_no": order_no,
                "action": ORDER_ACTION_BUY if order_info["direction"] == 'buy' else ORDER_ACTION_SELL,
                "symbol": self._contract['instrument_id'],
                "price": order_info["price"],
                "quantity": order_info["volume"],
                "trade_type": trade_type
            }
            order = Order(**info)
        order.remain = remain
        order.status = status
        order.avg_price = order_info["trade_avg_price"]
        order.ctime = ctime
        order.utime = ctime

        order.profit = order_info.get('profit', 0)
        order.fee = order_info.get('fee', 0)

        self._orders[order_no] = order
        if status in [ORDER_STATUS_FAILED, ORDER_STATUS_CANCELED, ORDER_STATUS_FILLED]:
            self._orders.pop(order_no)

        if order and self._order_update_callback:
            SingleTask.run(self._order_update_callback, copy.copy(order))

    def _update_position(self, position_infos):
        """ 更新持仓信息
        @param position_info 持仓信息
        """

        for position_info in position_infos:

            if position_info['contract_code'] == self._contract['instrument_id']:

                # 多仓
                if position_info['direction'] == 'buy':
                    self._position.long_quantity = int(position_info["volume"])
                    self._position.long_avg_price = position_info["cost_hold"]

                # 空仓
                if position_info['direction'] == 'sell':
                    self._position.short_quantity = int(position_info["volume"])
                    self._position.short_avg_price = position_info["cost_hold"]
                
                
                # self._position.liquid_price = position_info["liquidation_price"]
                # self._position.utime = position_info["ts"]

                if self._position and self._position_update_callback:
                    SingleTask.run(self._position_update_callback, copy.copy(self._position))

    async def on_event_asset_update(self, asset: Asset):
        """ 资产数据更新回调
        """
        self._assets = asset
        SingleTask.run(self._asset_update_callback, asset)

    async def get_history_kline(self, period, size):
        """ 获取历史行情
        """

        kline, error = await self._rest_api.get_history_kline(self._symbol, period, size)


        if error:
            logger.error('获取行情数据失败', caller=self)
            return None, error
        else:
            data = []
            for item in kline:
                info = {
                    'o': item['open'],
                    'h': item['high'],
                    'l': item['low'],
                    'c': item['close'],
                    'v': item['vol'],
                    't': item['id']
                }
                data.append(info)

            return data, error


    async def get_order_info(self, order_no):
        """ 获取订单详情
        """
        order_infos, error = await self._rest_api.get_order_info(self._contract['instrument_id'], order_no)

        if error:
            return None, error
        else:
            for order_info in order_infos:
                order = self._update_order(order_info)
                return copy.copy(order), None





# from quant.tasks import SingleTask

# host = "https://api.hbdm.com"
# access_key = 'dbye2sf5t7-7bf8354e-2939ebf8-cd13a'
# secret_key = 'b61680ce-b70ec43c-7fc9da65-31950'

# huobi = HuobiFutureRestAPI(host, access_key, secret_key)

# from quant.quant import quant

# quant.initialize()
# # SingleTask.run(huobi.get_order_list, 'BCH-USD-190927', '-1')
# SingleTask.run(huobi.revoke_order, 'BCH-USD-190927', '22896')

# quant.start()




